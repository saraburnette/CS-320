import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

    public void addContact(Contact contact) {
        if (!contacts.containsKey(contact.getContactId())) {
            contacts.put(contact.getContactId(), contact);
        }
    }

    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    public void updateContactFirstName(String contactId, String firstName) {
        Contact contact = getContact(contactId);
        contact.setFirstName(firstName);
    }

    public void updateContactLastName(String contactId, String lastName) {
        Contact contact = getContact(contactId);
        contact.setLastName(lastName);
    }

    public void updateContactPhone(String contactId, String phone) {
        Contact contact = getContact(contactId);
        contact.setPhone(phone);
    }

    public void updateContactAddress(String contactId, String address) {
        Contact contact = getContact(contactId);
        contact.setAddress(address);
    }

    public Map<String, Contact> getContacts() {
        return contacts;
    }

    private Contact getContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact not found with ID: " + contactId);
        }
        return contacts.get(contactId);
    }
}


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class ContactTest {

    @Test
    void testCreateValidContact() {
        Date currentDate = new Date();
        Date futureDate = new Date(currentDate.getTime() + (1000 * 60 * 60 * 24)); // One day into the future

        Contact validContact = new Contact("1234567890", "John", "Doe", "1234567890", "Valid Address");

        Assertions.assertEquals("1234567890", validContact.getContactId());
        Assertions.assertEquals("John", validContact.getFirstName());
        Assertions.assertEquals("Doe", validContact.getLastName());
        Assertions.assertEquals("1234567890", validContact.getPhone());
        Assertions.assertEquals("Valid Address", validContact.getAddress());
    }

    @Test
    void testCreateContactWithInvalidContactId() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "Valid Address");
        });
    }

    @Test
    void testCreateContactWithInvalidFirstName() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "Johnnnnnnnnnn", "Doe", "1234567890", "Valid Address");
        });
    }

    @Test
    void testCreateContactWithInvalidLastName() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "DoeDoeDoeDoe", "1234567890", "Valid Address");
        });
    }

    @Test
    void testCreateContactWithInvalidPhone() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "12345", "Valid Address");
        });
    }

    @Test
    void testCreateContactWithInvalidAddress() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "1234567890", "Invalid Addressssssssssssssssssss");
        });
    }
}
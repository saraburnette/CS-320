import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Map;

public class ContactServiceTest {

    @Test
    void testAddContact() {
        ContactService contactService = new ContactService();

        // Valid contact
        Contact validContact = new Contact("1234567890", "John", "Doe", "1234567890", "Valid Address");
        contactService.addContact(validContact);

        Map<String, Contact> contacts = contactService.getContacts();
        Assertions.assertTrue(contacts.containsKey("1234567890"));
        Assertions.assertEquals(validContact, contacts.get("1234567890"));
    }

    @Test
    void testDeleteContact() {
        ContactService contactService = new ContactService();

        // Valid contact
        Contact validContact = new Contact("1234567890", "John", "Doe", "1234567890", "Valid Address");
        contactService.addContact(validContact);

        contactService.deleteContact("1234567890");

        Map<String, Contact> contacts = contactService.getContacts();
        Assertions.assertFalse(contacts.containsKey("1234567890"));
    }

    @Test
    void testUpdateContactFirstName() {
        ContactService contactService = new ContactService();

        // Valid contact
        Contact validContact = new Contact("1234567890", "John", "Doe", "1234567890", "Valid Address");
        contactService.addContact(validContact);

        contactService.updateContactFirstName("1234567890", "Jane");

        Map<String, Contact> contacts = contactService.getContacts();
        Assertions.assertEquals("Jane", contacts.get("1234567890").getFirstName());
    }

   
}
